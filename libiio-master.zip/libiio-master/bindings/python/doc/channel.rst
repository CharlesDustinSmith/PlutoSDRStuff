Channels
==================

Members
--------------
.. autoclass:: iio.Channel
   :members:

--------------------

Channel attributes
--------------------
.. autoclass:: iio.DataFormat
   :members:
.. autoclass:: iio.ChannelModifier
   :members:
.. autoclass:: iio.ChannelType
   :members:
